SAÉ 14 - Se présenter sur Internet
Ruben Candélibes - BUT 1 Réseaux et Télécommunications - IUT de Rouen

COMMENT OUVRIR LE SITE
Ouvrir le fichier index.html avec un navigateur web (double-clic).
Le menu permet ensuite d'aller sur les autres pages.
Le bouton "English" en haut à droite affiche la version anglaise de la page,
le bouton "Français" revient à la version française.

ORGANISATION DES FICHIERS
sae14_Candelibes/
    index.html            page Accueil (français)
    parcours.html         page Présentation / parcours (français)
    projets.html          page Projets et centres d'intérêt (français)
    index-en.html         page Accueil (anglais)
    parcours-en.html      page Présentation (anglais)
    projets-en.html       page Projets (anglais)
    style.css             feuille de style commune à toutes les pages
    images/               logo et photos du site
    documents/            CV au format PDF
    README.txt            ce fichier

PHOTOS A AJOUTER DANS LE DOSSIER images/
    photo-accueil.jpg
    photo-rt-1.jpg
    photo-rt-2.jpg
    photo-bac-1.jpg
    photo-bac-2.jpg
    photo-sae16.jpg
    photo-sae11.jpg
    photo-arma3.png
    photo-sport.jpg
    photo-gendarmerie.jpg

NAVIGATEURS UTILISES POUR LES TESTS
    Google Chrome
    Mozilla Firefox

RESSOURCES EXTERNES
    Polices : Poppins et Open Sans - Google Fonts (https://fonts.google.com), licence SIL Open Font License
    Logo : Université de Rouen Normandie
    Photos : photos personnelles
    Technologies : HTML5 et CSS3 uniquement, sans JavaScript ni framework CSS
